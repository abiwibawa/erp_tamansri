<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class master_popup_m extends CI_Model{

	function caricustomer($key,$filter){
		if($filter == "kode"){
			$where = "WHERE upper(kode_customer) like upper('%$key%')";
		}elseif($filter == "nama"){
			$where = "WHERE upper(nama) like upper('%$key%')";
		}else{
			$where = "";
		}
		
		$query = $this->db->query("Select * from mastercustomer $where");
		return $query->result();
	}
	
	function cariproduk($key,$filter){
		if($filter == "kode"){
			$where = "AND upper(kode_barang) like upper('%$key%')";
		}elseif($filter == "nama"){
			$where = "AND upper(nama_barang) like upper('%$key%')";
		}else{
			$where = "";
		}
		
		$query = $this->db->query("Select * from masterbarang where id_jenis_barang='1' $where");
		return $query->result();
	}
	
	function cariproduk_order($id_order){
		$query = $this->db->query("SELECT
													od.id_order_det,
													od.id_barang,
													mb.nama_barang,
													mb.kode_barang,
													od.satuan,
													od.kuantitas,
													od.harga
												FROM
												order_det od LEFT JOIN
												masterbarang mb ON od.id_barang=mb.id_barang
												WHERE od.id_order='$id_order' ");
		return $query->result();
	}
	
	function cariptempdokumen($key=null){
		if(!empty($key))
			$where = "WHERE a.no_dokumen = '$key' ";
		else
			$where = "";
		
		$query = $this->db->query("select a.id_order,a.no_dokumen,b.kode_customer,b.nama from temp_order a left join mastercustomer b on a.id_customer=b.id_customer  $where");
		return $query->result();
	}
	
	function caripreorder($key=null){
		$where = "";
		if(!empty($key)){
			$this->db->where('no_dokumen',$key);
		}
		
		$this->db->where('terkirim IS NULL',null,false);
		$query = $this->db->get('order');
		return $query->result();
	}
	
	function carisupir($key=null,$tabel){
		if(!empty($key))
			$this->db->like('UPPER(nama)',strtoupper($key));
		
		$query = $this->db->get($tabel);
		return $query->result();
	}
}
