<div class="row">                
	<div class="col-md-12">
		<div class="block block-transparent">
			<div class="content">                
				<h1>Aplikasi Enterprice Resource Planning (E.R.P)</h1>
				<p class="lead">PT Taman Sriwedari Paper Core Industri Kediri - Indonesia.</p>
			</div>
		</div>
		<div class="block block-transparent">
			<div class="content">
				
				<h4>Addresses</h4>
				<address>
					<strong>Jl. Mataram 155, Dsn Gambang, Ds Karangrejo</strong><br>
					Kec.Ngasem, Kab.Kediri<br>
					Telp (0354)686358-694069<br>
					Fax (0354)690690<br>
				</address>    
			</div>
		</div>
	</div>
</div>