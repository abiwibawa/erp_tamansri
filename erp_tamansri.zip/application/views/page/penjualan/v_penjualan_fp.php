<script>
	function popupcaricustomer(){
		var vurl = "<?=base_url('master_popup/caricustomer')?>";
		window.open(vurl,'popuppage','width=700,toolbar=0,resizable=1,scrollbars=yes,height=500,top=100,left=100,address=0');
	}
	
	function popupproduk(){
		var vurl = "<?=base_url('master_popup/cariproduk')?>";
		window.open(vurl,'popuppage','width=700,toolbar=0,resizable=1,scrollbars=yes,height=500,top=100,left=100,address=0');
	}
</script>
<div class="row">             
	<div class="col-md-12">
		<div class="block">
			<div class="content">
				<div class="header">
					<h2>Faktur Pajak</h2>
					<div class="side pull-right">
						<button class="simpan_order btn btn-primary" data-url="<?=base_url('penjualan_order/aprove_order')?>">
							<i class="icon-save"></i>&nbsp;&nbsp;simpan
						</button>
						
						<button class="clearform btn btn-primary">
							<i class="icon-print"></i>&nbsp;&nbsp;print
						</button>
						
						<button class="clearform btn btn-primary">
							<i class="icon-refresh"></i>&nbsp;&nbsp;clear
						</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<form action="<?=$action_form?>" id="form_order" method="post">
	<input type="hidden" name="id_order" id="id_order" value="">
	<div class="col-md-8">
		<div class="block block-fill-white">
			<div class="header">
				<h4>Header</h4>
			</div>				
			<div class="content controls">				
				<div class="form-row">
					<div class="col-md-2">Kode Transaksi</div>
					<div class="col-md-1"><?=form_input('kode_transaksi','','class="form-control" ')?></div>
					<div class="col-md-3">&nbsp;</div>
					<div class="col-md-2">Tanggal</div>
					<div class="col-md-3">
						<div class="input-group">
							<div class="input-group-addon"><span class="icon-calendar-empty"></span></div>
							<?=form_input('tanggal','','class="datepicker form-control" id="tanggal" ')?>
						</div>
					</div>
				</div>
				
				<div class="form-row">
					<div class="col-md-2">No. Faktur</div>
					<div class="col-md-4"><?=form_input('no_faktur','','class="form-control" readonly')?></div>
				</div>
				
				<div class="form-row">
					<div class="col-md-2">No.Surat Jalan</div>
					<div class="col-md-3"><?=form_input('no_dokumen',$this->input->post('no_dokumen'),' class="form-control" id="no_dokumen" readonly')?></div>
					<div class="col-md-1"><button type="button" id="btn_cari_custom" class="btn btn-success" onclick="popupcarinosuratjalan()">cari</button></div>
					
					<div class="col-md-2">Tanda Tangan Surat</div>
					<div class="col-md-3"><?=form_input('no_dokumen',$this->input->post('no_dokumen'),' class="form-control" id="no_dokumen" readonly')?></div>
					<div class="col-md-1"><button type="button" id="btn_cari_custom" class="btn btn-success" onclick="popupcarinosuratjalan()">cari</button></div>
				</div>
				
				<div class="form-row">
					<div class="col-md-2">&nbsp;</div>
					<div class="col-md-2">&nbsp;</div>
				</div>
				
				<div class="form-row">
					<div class="col-md-6">Pengusaha Kena Pajak :</div>
					<div class="col-md-6">Pembeli Barang / Penerima Jasa Kena Pajak :</div>
				</div>
				<div class="form-row">
					<div class="col-md-1">Nama</div>
					<div class="col-md-5"><?=form_input('kode_customer','PT. TAMAN SRIWEDARI','class="form-control" id="kode_customer" readonly')?></div>
					
					<div class="col-md-1">Nama</div>
					<div class="col-md-5"><?=form_input('kode_customer','','class="form-control" id="kode_customer" readonly ')?></div>
				</div>
				<div class="form-row">
					<div class="col-md-1">Alamat</div>
					<div class="col-md-5"><textarea readonly>Jl. Sersan KKo Usman NO.27, Dandangan, Kediri, Jawa Timur</textarea></div>
					
					<div class="col-md-1">Alamat</div>
					<div class="col-md-5"><textarea readonly></textarea></div>
				</div>
				<div class="form-row">
					<div class="col-md-1">N.P.W.P</div>
					<div class="col-md-5"><?=form_input('kode_customer','01.141.098.2-2651.000','class="form-control" id="kode_customer" readonly ')?></div>
					
					<div class="col-md-1">N.P.W.P</div>
					<div class="col-md-5"><?=form_input('kode_customer','','class="form-control" id="kode_customer" readonly ')?></div>
				</div>								
			</div>
		</div>
	</div>
	
	<div class="col-md-4">
		<div class="block block-fill-white">
			<div class="header">
				<h2>Biaya</h2>
			</div>				
			<div class="content controls">
				<div class="form-row">
					<div class="col-md-4">Jumlah Harga Jual:</div>
					<div class="col-md-7"><?=form_input('subtotal','','class="form-control" id="subtotal" readonly="readonly" ')?></div>
				</div>
				
				<div class="form-row">
					<div class="col-md-4">Dikurangi Potongan Harga:</div>
					<div class="col-md-7"><?=form_input('pengiriman','0','class="form-control" id="pengiriman" ')?></div>
				</div>
				
				<div class="form-row">
					<div class="col-md-4">Dikurangi Uang Muka:</div>
					<div class="col-md-7"><?=form_input('pengiriman','0','class="form-control" id="pengiriman" ')?></div>
				</div>
				
				<div class="form-row">
					<div class="col-md-4">Dasar Pengenaan Pajak:</div>
					<div class="col-md-7"><?=form_input('pengiriman','0','class="form-control" id="pengiriman" ')?></div>
				</div>
				
				<div class="form-row">
					<div class="col-md-4">10% X Dasar Pengenaan Pajak :</div>
					<div class="col-md-7"><?=form_input('total_harga','','class="form-control" id="total_harga" readonly="readonly" ')?></div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="col-md-12">
		<div class="block block-fill-white">
			<div class="header">
				<h4>Detail Item</h4>
			</div>
			<div class="content">
				<table cellpadding="0" cellspacing="0" width="100%" class="table table-bordered table-striped">
				<thead>
					<tr>
						<th width="5%">No</th>
						<th width="25%">Nama Barang Kena Pajak/Jasa Kena Pajak</th>
						<th width="5%">Harga Jual/Penggantian Uang Muka/Termijin<br>(Rp)</th>                  
					</tr>
				</thead>
				<tbody>
				</tbody>
				</table>
			</div>
		</div>
	</div>
	</form>
</div>