<div class="row">
	<div class="col-md-12">
		<ol class="breadcrumb">
			<li><a href="#">Home</a></li>                    
			<li><a href="#">Components</a></li>
			<li><a href="#">Layouts</a></li>
			<li class="active">Content scroll</li>
		</ol>
	</div>
</div>